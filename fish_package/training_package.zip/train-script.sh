#!/bin/bash
sleap-train centroid.json project.pkg.slp
sleap-train centered_instance.json project.pkg.slp
